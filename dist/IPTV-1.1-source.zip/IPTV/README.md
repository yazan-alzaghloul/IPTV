# IPTV for Android — modernization release 1.1

This release enhances the existing Kotlin/Compose application. It retains Xtream, encrypted account storage, favorites, short EPG and Media3 playback, and adds:

- Cinematic Home with provider artwork/metadata, optional artwork rotation, live/movie/series rows, favorites, recently watched channels and continue watching.
- Adaptive bottom navigation on phones and a scrollable side navigation on larger screens/TV; section scroll/focus restoration and card long-press favorites.
- Cancellable 180-ms-debounced catalog search, universal search across loaded channels/movies/series, category filtering and provider/name/recent/rating sorting.
- A five-minute, three-section in-memory cache; explicit refresh retains loaded content on failure. Search/filtering/sorting and provider catalog mapping run off the main thread.
- Bounded local history, completion indicators, restart/resume and season selection. Existing account, favorite and position storage keys remain readable.
- Appearance settings for dark/light, violet/ocean accents, high contrast, text scale, home visibility and landing section; credential-free appearance import/export and artwork/history cleanup.
- Media3 1.11.1 with fit/fill/zoom, video quality selection, PiP, safe diagnostics, at most two app-level transient reconnect attempts and reuse of the player for adjacent live channels.

This is the first implementation increment of the master brief, not completion of every planned commercial feature. Full XMLTV/timeline EPG, M3U imports, multiple providers, persistent catalog indexing, profiles/parental controls, complete Arabic localization, Cast/DRM-license integrations, downloads and AI are tracked in [the roadmap](docs/MODERNIZATION_ROADMAP.md). Existing short EPG remains functional. No provider account or sample media is bundled in the application APK.

See [the audit](docs/MODERNIZATION_AUDIT.md) and [current validation](docs/MODERNIZATION_VALIDATION.md). The older `docs/VERIFICATION.md` records version 1.0 checks only.

A native Kotlin / Jetpack Compose Xtream IPTV client for Android phones, tablets, and Android TV (Android 8.0 / API 26 or later). A provider subscription is required. This app does not include content or run a CCcam server.

## Install

Download `dist/IPTV-debug.apk` to your phone or TV and open it. Allow installation from that file manager when Android prompts. This APK is signed with the development machine's debug key and is intended for testing, not store distribution.

With Android platform tools:

```sh
adb install -r dist/IPTV-debug.apk
```

Open **IPTV** in the launcher. Enter your provider host or base URL, optional port, username, and password, then choose **Connect**. A full URL's scheme takes precedence over the HTTP/HTTPS selector; an entered port overrides the URL port. Base paths such as `https://provider.example/service/` are preserved. Use a base URL rather than an M3U link or `player_api.php` link.

Browse Live TV, Movies, Series, or Favorites. Open a title for details and playback. Series show playable episodes sorted by season and episode. Live channel details show current and upcoming programs when timestamped EPG is available. The player settings menu selects available audio and subtitle tracks; seeking is available for on-demand content. Live stream failures offer an HLS / MPEG-TS switch for providers that only support one output format.

Use touch on phones or directional keys and Select on a TV remote. Back exits playback to details, then returns to the catalog. Signing out removes the saved account, favorites, and playback positions.

## Build and test

Open this folder in Android Studio, or install JDK 17 or 21 and Android SDK Platform 36. Set `ANDROID_HOME` or create an untracked `local.properties` with `sdk.dir=/path/to/android/sdk`.

```sh
./gradlew assembleDebug testDebugUnitTest lintDebug
# With an Android emulator or device attached:
./gradlew connectedQaAndroidTest
```

The APK is generated at `app/build/outputs/apk/debug/app-debug.apk`. The QA build uses application ID `com.iptv.app.qa` so tests do not clear the normal app account. Tests use an in-process fixture server and official Media3 sample clips; they do not require provider credentials. See `docs/MODERNIZATION_VALIDATION.md` for the checks completed on this build.

## Structure

- `Provider.kt`: provider interface, Xtream API client, account validation, catalog/detail/EPG parsing, and encoded playback URLs.
- `Storage.kt`: credential and library interfaces, Android Keystore AES-GCM storage, account-scoped favorites and resume positions.
- `AppViewModel.kt`: cancellable catalog/detail loading and session state.
- `MainActivity.kt`: responsive Compose login, catalog, and detail screens, including remote focus outlines.
- `PlayerActivity.kt`: Media3 playback, media session, lifecycle handling, retry, and periodic resume checkpoints.

## Privacy and compatibility

Credentials are encrypted with a non-exportable Android Keystore key. Backup and device transfer are disabled for app data. Provider requests and stream URLs contain the provider's required credentials; the app does not log these URLs. Media3 logging is disabled. Favorites and playback positions are private local preferences scoped by a SHA-256 account identifier. No analytics or custom backend is used.

HTTP providers are supported, with an in-app notice that HTTP is unencrypted. HTTPS is recommended and certificate validation remains enabled. Artwork is fetched from provider-supplied URLs. Android device codec capabilities determine which streams can play.

This release supports one account, English UI, live TV, movies, series, local favorites/history, on-demand resume, and short EPG. It excludes recording, downloads, casting, catch-up, full EPG grids, and Google Play publishing. Provider-specific API differences and DRM-protected streams require separate compatibility work.
