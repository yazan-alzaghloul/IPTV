package com.iptv.app

import android.app.Activity
import android.app.AlertDialog
import android.app.PictureInPictureParams
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Rational
import android.view.*
import android.widget.*
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.*
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.upstream.DefaultLoadErrorHandlingPolicy
import androidx.media3.session.MediaSession
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.google.gson.Gson

interface PlaybackEngine {
    val player: Player
    fun open(url: String, position: Long, live: Boolean)
    fun release()
}
@UnstableApi
class Media3Engine(context: android.content.Context) : PlaybackEngine {
    override val player = ExoPlayer.Builder(context)
        .setMediaSourceFactory(DefaultMediaSourceFactory(DefaultHttpDataSource.Factory()
            .setUserAgent("IPTV/1.1 Android").setConnectTimeoutMs(15_000).setReadTimeoutMs(30_000)
            .setAllowCrossProtocolRedirects(true)).setLoadErrorHandlingPolicy(DefaultLoadErrorHandlingPolicy(1)))
        .setAudioAttributes(AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(), true)
        .setHandleAudioBecomingNoisy(true).build()
    override fun open(url: String, position: Long, live: Boolean) {
        player.setMediaItem(MediaItem.fromUri(url))
        if (!live && position > 0) player.seekTo(position)
        player.prepare()
        player.playWhenReady = true
    }
    override fun release() = player.release()
}

@UnstableApi
class PlayerActivity : Activity() {
    private lateinit var item: CatalogItem
    private var credentials: Credentials? = null
    private lateinit var library: LibraryRepository
    private var engine: PlaybackEngine? = null
    private var session: MediaSession? = null
    private lateinit var video: PlayerView
    private lateinit var errorPanel: LinearLayout
    private lateinit var errorText: TextView
    private lateinit var header: LinearLayout
    private lateinit var title: TextView
    private var queue: List<CatalogItem> = emptyList()
    private var previousLive: CatalogItem? = null
    private var useTransportStream = false
    private var resumeWhenReady = true
    private var restartRequested = false
    private var aspect = AspectRatioFrameLayout.RESIZE_MODE_FIT
    private val retries = RetryBudget()
    private var retryTask: Runnable? = null
    private val handler = Handler(Looper.getMainLooper())
    private val checkpoint = object : Runnable {
        override fun run() { savePosition(); handler.postDelayed(this, 5_000) }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // URLs required by providers contain credentials. Never include them in library logs.
        androidx.media3.common.util.Log.setLogLevel(androidx.media3.common.util.Log.LOG_LEVEL_OFF)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        library = LocalLibrary(PreferenceValues(this))
        val decoded = runCatching { Gson().fromJson(savedInstanceState?.getString("currentItem") ?: intent.getStringExtra("item"), CatalogItem::class.java) }.getOrNull()
        if (decoded == null) { finish(); return }
        item = decoded
        queue = runCatching { Gson().fromJson(intent.getStringExtra("queue") ?: "[]", Array<CatalogItem>::class.java).toList().take(50) }.getOrDefault(emptyList())
        credentials = runCatching { SecureCredentialStore(this).read() }.getOrNull()
        if (credentials == null) { finish(); return }
        resumeWhenReady = savedInstanceState?.getBoolean("playWhenReady", true) ?: true
        restartRequested = savedInstanceState == null && intent.getBooleanExtra("restart", false)
        useTransportStream = savedInstanceState?.getBoolean("transportStream") ?: false
        aspect = savedInstanceState?.getInt("aspect") ?: AspectRatioFrameLayout.RESIZE_MODE_FIT
        val frame = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        video = PlayerView(this).apply {
            keepScreenOn = true
            resizeMode = aspect
            setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
            setShowSubtitleButton(true)
            setShowNextButton(false); setShowPreviousButton(false)
            setShowFastForwardButton(item.kind != ContentKind.LIVE); setShowRewindButton(item.kind != ContentKind.LIVE)
            controllerShowTimeoutMs = 4_000
        }
        frame.addView(video, FrameLayout.LayoutParams(-1, -1))
        header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(8))
            setBackgroundColor(0xE0080B12.toInt())
        }
        val heading = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        heading.addView(button("Back") { finish() })
        title = TextView(this).apply {
            text = item.name; textSize = 18f; setTextColor(Color.WHITE); maxLines = 2
            ellipsize = android.text.TextUtils.TruncateAt.END; setPadding(dp(16), 0, 0, 0)
        }
        heading.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(heading)
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        controls.addView(button("Aspect") { selectAspect() })
        controls.addView(button("Quality") { selectQuality() })
        controls.addView(button("Info") { diagnostics() })
        if (packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)) controls.addView(button("Picture-in-picture") {
            runCatching { enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build()) }
                .onFailure { Toast.makeText(this, "Picture-in-picture is unavailable on this device.", Toast.LENGTH_SHORT).show() }
        })
        if (item.kind == ContentKind.LIVE && queue.size > 1) {
            controls.addView(button("Channel −") { switchChannel(-1) })
            controls.addView(button("Channel +") { switchChannel(1) })
            controls.addView(button("Previous channel") { previousLive?.let { switchTo(it) } })
        }
        header.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(controls) })
        frame.addView(header, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))
        errorPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(dp(24), dp(24), dp(24), dp(24)); setBackgroundColor(0xF0080B12.toInt()); visibility = View.GONE
        }
        errorText = TextView(this).apply { textSize = 18f; setTextColor(Color.WHITE); gravity = Gravity.CENTER }
        errorPanel.addView(errorText)
        errorPanel.addView(button("Retry playback") { open(manual = true) })
        if (item.kind == ContentKind.LIVE) errorPanel.addView(button("Switch HLS / MPEG-TS") {
            useTransportStream = !useTransportStream; open(manual = true)
        })
        errorPanel.addView(button("Back to details") { finish() })
        frame.addView(errorPanel, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER))
        video.setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { visible -> header.visibility = if (isInPictureInPictureMode) View.GONE else visible })
        setContentView(frame)
    }
    override fun onStart() {
        super.onStart()
        if (!::video.isInitialized || credentials == null) return
        val playback = Media3Engine(this)
        engine = playback
        video.player = playback.player
        session = MediaSession.Builder(this, playback.player).build()
        playback.player.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                val transient = error.errorCode == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED || error.errorCode == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT
                val delay = if (transient) retries.nextDelayMs() else null
                errorText.text = when {
                    delay != null -> "Connection interrupted. Reconnecting (${retries.attempts}/2)…"
                    transient -> "Connection interrupted. Check your network, then retry."
                    error.errorCode == PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS -> "The provider refused this stream. Check your subscription or try again later."
                    error.errorCode == PlaybackException.ERROR_CODE_DECODING_FAILED || error.errorCode == PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED -> "This device cannot decode this stream. Try another title or audio track."
                    error.errorCode in 6000..6999 -> "This stream requires a supported DRM license configuration."
                    else -> "This stream is unavailable or unsupported. Retry or choose another title."
                }
                errorPanel.visibility = View.VISIBLE
                if (delay != null) {
                    retryTask?.let { handler.removeCallbacks(it) }
                    retryTask = Runnable { open(manual = false) }.also { handler.postDelayed(it, delay) }
                } else errorPanel.getChildAt(1).requestFocus()
            }
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED) savePosition()
            }
        })
        open(manual = false)
        playback.player.playWhenReady = resumeWhenReady
        video.requestFocus(); video.showController()
        handler.postDelayed(checkpoint, 5_000)
    }
    private fun open(manual: Boolean) {
        val c = credentials ?: return
        val playback = engine ?: return
        retryTask?.let { handler.removeCallbacks(it) }; retryTask = null
        if (manual) retries.reset()
        val position = if (restartRequested) 0L else playback.player.currentPosition.takeIf { it > 0 } ?: library.position(c, item)
        restartRequested = false
        val base = XtreamRepository().streamUrl(c, item)
        val url = if (useTransportStream && item.kind == ContentKind.LIVE) base.removeSuffix("m3u8") + "ts" else base
        errorPanel.visibility = View.GONE
        playback.open(url, position, item.kind == ContentKind.LIVE)
        video.requestFocus()
    }
    private fun switchChannel(delta: Int) {
        val index = queue.indexOfFirst { it.key == item.key }
        if (index >= 0) queue.getOrNull(index + delta)?.let(::switchTo)
    }
    private fun switchTo(next: CatalogItem) {
        if (next.key == item.key) return
        savePosition(); previousLive = item; item = next
        title.text = next.name; useTransportStream = false; retries.reset()
        open(manual = false) // Reuse the same player and MediaSession; never open a second stream.
        video.showController()
    }
    private fun savePosition() {
        val c = credentials ?: return
        val player = engine?.player ?: return
        if (player.playbackState == Player.STATE_ENDED) library.savePosition(c, item, player.duration.coerceAtLeast(0), player.duration)
        else if (player.playbackState == Player.STATE_READY || player.currentPosition > 0)
            library.savePosition(c, item, player.currentPosition, player.duration)
    }
    private fun selectAspect() {
        val modes = intArrayOf(AspectRatioFrameLayout.RESIZE_MODE_FIT, AspectRatioFrameLayout.RESIZE_MODE_FILL, AspectRatioFrameLayout.RESIZE_MODE_ZOOM)
        AlertDialog.Builder(this).setTitle("Aspect ratio").setSingleChoiceItems(arrayOf("Fit", "Fill", "Zoom"), modes.indexOf(aspect)) { dialog, which ->
            aspect = modes[which]; video.resizeMode = aspect; dialog.dismiss()
        }.setNegativeButton("Cancel", null).show()
    }
    private fun selectQuality() {
        val player = engine?.player ?: return
        val choices = player.currentTracks.groups.filter { it.type == C.TRACK_TYPE_VIDEO }.flatMap { group ->
            (0 until group.length).filter { group.isTrackSupported(it) }.map { index ->
                val format = group.getTrackFormat(index)
                Triple(group, index, if (format.height > 0) "${format.height}p${if (format.bitrate > 0) " · ${format.bitrate / 1000} kbps" else ""}" else "Video track ${index + 1}")
            }
        }
        AlertDialog.Builder(this).setTitle("Playback quality").setItems((listOf("Automatic") + choices.map { it.third }).toTypedArray()) { _, which ->
            val builder = player.trackSelectionParameters.buildUpon().clearOverridesOfType(C.TRACK_TYPE_VIDEO)
            if (which > 0) choices[which - 1].let { builder.addOverride(TrackSelectionOverride(it.first.mediaTrackGroup, it.second)) }
            player.trackSelectionParameters = builder.build()
        }.setNegativeButton("Cancel", null).show()
    }
    private fun diagnostics() {
        val player = engine?.player ?: return
        val format = (player as? ExoPlayer)?.videoFormat
        val description = "${format?.sampleMimeType ?: "Video information unavailable"}\n${format?.width ?: 0} × ${format?.height ?: 0}\nBuffered: ${player.totalBufferedDuration / 1000} s\nReconnect attempts: ${retries.attempts}/2\nSource mode: ${if (useTransportStream) "MPEG-TS" else "Automatic / HLS"}"
        AlertDialog.Builder(this).setTitle("Playback diagnostics").setMessage(description).setPositiveButton("Close", null).show()
    }
    override fun onPictureInPictureModeChanged(inPip: Boolean, newConfig: android.content.res.Configuration) {
        super.onPictureInPictureModeChanged(inPip, newConfig)
        if (::video.isInitialized) { video.useController = !inPip; header.visibility = if (inPip) View.GONE else View.VISIBLE }
    }
    override fun onStop() {
        handler.removeCallbacks(checkpoint); retryTask?.let { handler.removeCallbacks(it) }; retryTask = null
        resumeWhenReady = engine?.player?.playWhenReady ?: resumeWhenReady
        savePosition(); session?.release(); session = null
        if (::video.isInitialized) video.player = null
        engine?.release(); engine = null
        super.onStop()
    }
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (::video.isInitialized && item.kind == ContentKind.LIVE && event.action == KeyEvent.ACTION_DOWN && event.keyCode in listOf(KeyEvent.KEYCODE_CHANNEL_UP, KeyEvent.KEYCODE_CHANNEL_DOWN)) {
            switchChannel(if (event.keyCode == KeyEvent.KEYCODE_CHANNEL_UP) 1 else -1); return true
        }
        if (::video.isInitialized && event.keyCode != KeyEvent.KEYCODE_BACK && errorPanel.visibility != View.VISIBLE && video.dispatchKeyEvent(event)) return true
        return super.dispatchKeyEvent(event)
    }
    override fun onSaveInstanceState(outState: Bundle) {
        outState.putBoolean("transportStream", useTransportStream)
        outState.putBoolean("playWhenReady", engine?.player?.playWhenReady ?: resumeWhenReady)
        outState.putInt("aspect", aspect); outState.putString("currentItem", Gson().toJson(item))
        super.onSaveInstanceState(outState)
    }
    private fun button(label: String, action: () -> Unit) = Button(this).apply { text = label; minimumHeight = dp(48); setOnClickListener { action() } }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
