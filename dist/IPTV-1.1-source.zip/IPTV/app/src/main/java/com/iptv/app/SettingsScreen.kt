package com.iptv.app

import android.app.ActivityManager
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil.imageLoader
import com.google.gson.Gson
import kotlinx.coroutines.*

@OptIn(coil.annotation.ExperimentalCoilApi::class)
@Composable fun SettingsScreen(s: AppState, update: (Appearance) -> Unit, clearHistory: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var message by remember { mutableStateOf<String?>(null) }
    var clearConfirm by remember { mutableStateOf(false) }
    val a = s.appearance
    val export = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) scope.launch {
            val success = withContext(Dispatchers.IO) { runCatching {
                context.contentResolver.openOutputStream(uri)!!.bufferedWriter().use { it.write(Gson().toJson(a)) }
            }.isSuccess }
            message = if (success) "Appearance exported. Provider credentials are excluded." else "Could not export settings. Try another location."
        }
    }
    val import = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            val imported = withContext(Dispatchers.IO) { runCatching {
                val input = context.contentResolver.openInputStream(uri)!!.bufferedReader().use { reader ->
                    val buffer = CharArray(32_769); val length = reader.read(buffer)
                    require(length in 1..32_768); String(buffer, 0, length)
                }
                Gson().fromJson(input, Appearance::class.java).also {
                    require(it.theme in listOf("dark", "light") && it.accent in listOf("violet", "cyan"))
                    require(it.fontScale.isFinite() && it.fontScale in .85f..1.4f)
                    require(it.landing in listOf("HOME", "LIVE", "MOVIES")); require(it.hiddenRows.size <= 6)
                }
            }.getOrNull() }
            if (imported != null) { update(imported); message = "Appearance imported." } else message = "This is not a supported appearance settings file."
        }
    }
    if (clearConfirm) AlertDialog(onDismissRequest = { clearConfirm = false }, title = { Text("Clear watch history?") },
        text = { Text("This also resets saved progress for titles in your recent history. Favorites stay saved.") },
        confirmButton = { TextButton({ clearHistory(); clearConfirm = false; message = "Watch history cleared." }) { Text("Clear history") } },
        dismissButton = { TextButton({ clearConfirm = false }) { Text("Cancel") } })
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 24.dp), verticalArrangement = Arrangement.spacedBy(16.dp), contentPadding = PaddingValues(bottom = 32.dp)) {
        item { SettingsHeading("Appearance", "Make the library comfortable on your screen.") }
        item { ChoiceRow("Theme", listOf("dark" to "Cinematic dark", "light" to "Light"), a.theme) { update(a.copy(theme = it)) } }
        item { ChoiceRow("Accent", listOf("violet" to "Violet", "cyan" to "Ocean"), a.accent) { update(a.copy(accent = it)) } }
        item { ToggleSetting("High contrast", "Increase contrast for secondary text.", a.highContrast) { update(a.copy(highContrast = it)) } }
        item {
            Text("Text size · ${(a.fontScale * 100).toInt()}%", style = MaterialTheme.typography.titleMedium)
            Slider(a.fontScale, { update(a.copy(fontScale = it)) }, valueRange = .85f..1.4f, steps = 10, modifier = Modifier.focusRing())
            Text("Your device’s system text size is also respected.", color = Muted, style = MaterialTheme.typography.bodySmall)
        }
        item { SettingsHeading("Home", "Show the sections you use most.") }
        item { ChoiceRow("Open app to", listOf("HOME" to "Home", "LIVE" to "Live TV", "MOVIES" to "Movies"), a.landing) { update(a.copy(landing = it)) } }
        item { ToggleSetting("Optional motion", "Allow artwork rotation. System reduced-motion preferences take priority.", a.motion) { update(a.copy(motion = it)) } }
        item { ToggleSetting("Rotate featured artwork", "Changes artwork every 12 seconds while the hero is not focused. No video autoplay.", a.heroRotation) { update(a.copy(heroRotation = it)) } }
        items(listOf("Continue watching", "Recently watched channels", "Favorites", "Live TV", "Movies", "Series")) { row ->
            ToggleSetting(row, "Show on Home when content is available.", row !in a.hiddenRows) { visible -> update(a.copy(hiddenRows = if (visible) a.hiddenRows - row else a.hiddenRows + row)) }
        }
        item { SettingsHeading("Data & privacy", "Your account and viewing history stay on this device.") }
        item { Action("Clear watch history", Modifier.fillMaxWidth()) { clearConfirm = true } }
        item { Action("Clear artwork cache", Modifier.fillMaxWidth()) {
            scope.launch {
                withContext(Dispatchers.IO) { context.imageLoader.memoryCache?.clear(); context.imageLoader.diskCache?.clear() }
                message = "Artwork cache cleared."
            }
        } }
        item { Action("Export appearance", Modifier.fillMaxWidth()) { export.launch("IPTV-appearance.json") } }
        item { Action("Import appearance", Modifier.fillMaxWidth()) { import.launch(arrayOf("application/json", "text/plain")) } }
        item { Action("Reset appearance", Modifier.fillMaxWidth()) { update(Appearance()); message = "Appearance reset." } }
        message?.let { text -> item { Text(text, color = Sky) } }
        item {
            val manager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val connected = manager.activeNetwork?.let { manager.getNetworkCapabilities(it)?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) } == true
            val memory = (context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).memoryClass
            val version = context.packageManager.getPackageInfo(context.packageName, 0).versionName
            SettingsHeading("About & diagnostics", "IPTV $version · Android ${android.os.Build.VERSION.RELEASE}\nNetwork: ${if (connected) "validated" else "offline or unvalidated"} · App heap class: $memory MB\nMedia3 player · Encrypted account storage · No analytics")
        }
    }
}
@Composable private fun SettingsHeading(title: String, description: String) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(title, style = MaterialTheme.typography.titleLarge)
        Text(description, color = Muted, style = MaterialTheme.typography.bodyMedium)
    }
}
@Composable private fun ToggleSetting(title: String, description: String, checked: Boolean, change: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
        Column(Modifier.weight(1f)) { Text(title, style = MaterialTheme.typography.titleMedium); Text(description, color = Muted, style = MaterialTheme.typography.bodySmall) }
        Switch(checked, change, Modifier.focusRing())
    }
}
@Composable private fun ChoiceRow(title: String, values: List<Pair<String, String>>, current: String, select: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(title, style = MaterialTheme.typography.titleMedium)
        androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(values) { (value, label) -> FilterChip(current == value, { select(value) }, { Text(label) }, modifier = Modifier.focusRing()) }
        }
    }
}
