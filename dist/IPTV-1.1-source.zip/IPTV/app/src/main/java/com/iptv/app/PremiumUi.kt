package com.iptv.app

import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.*
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.*
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import kotlinx.coroutines.*

private fun Section.icon(): ImageVector = when (this) {
    Section.HOME -> Icons.Default.Home
    Section.LIVE -> Icons.Default.PlayArrow
    Section.MOVIES, Section.SERIES -> Icons.Default.Menu
    Section.FAVORITES -> Icons.Default.Favorite
    Section.SEARCH -> Icons.Default.Search
    Section.SETTINGS -> Icons.Default.Settings
}
@Composable fun PremiumShell(vm: AppViewModel, play: (CatalogItem) -> Unit) {
    val s = vm.state
    val screens = rememberSaveableStateHolder()
    var signOut by remember { mutableStateOf(false) }
    var libraryMenu by remember { mutableStateOf(false) }
    val focus = LocalFocusManager.current
    val keyboard = LocalSoftwareKeyboardController.current
    val navigate: (Section) -> Unit = { focus.clearFocus(); keyboard?.hide(); vm.selectSection(it) }
    val select: (CatalogItem) -> Unit = { focus.clearFocus(); keyboard?.hide(); vm.select(it) }
    BackHandler(s.section != Section.HOME) { navigate(Section.HOME) }
    if (signOut) AlertDialog(onDismissRequest = { signOut = false }, title = { Text("Sign out?") },
        text = { Text("This removes your saved login, favorites, history, and playback progress from this device.") },
        confirmButton = { TextButton({ signOut = false; vm.signOut() }, Modifier.focusRing()) { Text("Sign out") } },
        dismissButton = { TextButton({ signOut = false }, Modifier.focusRing()) { Text("Cancel") } })
    BoxWithConstraints(Modifier.fillMaxSize().safeDrawingPadding()) {
        val wide = maxWidth >= 840.dp
        Row(Modifier.fillMaxSize()) {
            if (wide) Column(Modifier.width(200.dp).fillMaxHeight().background(MaterialTheme.colorScheme.surfaceVariant).padding(16.dp)
                .verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("IPTV", Modifier.padding(vertical = 20.dp), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black, color = Sky)
                Section.entries.forEach { entry ->
                    NavigationDrawerItem(label = { Text(entry.label, maxLines = 1, overflow = TextOverflow.Ellipsis) }, selected = s.section == entry,
                        icon = { Icon(entry.icon(), null) }, onClick = { navigate(entry) }, modifier = Modifier.testTag("nav_${entry.name}").focusRing())
                }
            }
            Column(Modifier.weight(1f).fillMaxHeight()) {
                Row(Modifier.fillMaxWidth().padding(horizontal = if (wide) 28.dp else 20.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(if (s.section == Section.HOME) "Your next great watch" else s.section.label,
                            style = if (wide) MaterialTheme.typography.headlineMedium else MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Text(if (s.section == Section.HOME) "YOUR LIBRARY · YOUR WAY" else "From your provider’s library", style = MaterialTheme.typography.labelSmall, color = Muted)
                    }
                    TextButton({ signOut = true }, Modifier.focusRing()) { Text("Sign out") }
                    if (wide && s.section != Section.SETTINGS) IconButton({ navigate(Section.SEARCH) }, Modifier.focusRing()) { Icon(Icons.Default.Search, "Search library") }
                }
                if (!wide && s.section in listOf(Section.MOVIES, Section.SERIES, Section.FAVORITES)) Row(
                    Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(Section.MOVIES, Section.SERIES, Section.FAVORITES).forEach { entry ->
                        FilterChip(s.section == entry, { navigate(entry) }, { Text(entry.label) }, modifier = Modifier.testTag("nav_${entry.name}").focusRing())
                    }
                }
                Box(Modifier.weight(1f)) {
                    screens.SaveableStateProvider(s.section.name) {
                    when (s.section) {
                        Section.HOME -> HomeDashboard(s, select, play = { if (it.kind == ContentKind.SERIES) select(it) else play(it) }, toggle = vm::toggle, retry = vm::refresh)
                        Section.SETTINGS -> SettingsScreen(s, vm::appearance, vm::clearHistory)
                        else -> DiscoveryScreen(s, vm::search, vm::category, vm::sort, select, vm::toggle, vm::refresh)
                    }
                    }
                }
                if (!wide) {
                    NavigationBar(containerColor = MaterialTheme.colorScheme.surfaceVariant, tonalElevation = 0.dp) {
                        listOf(Section.HOME, Section.LIVE, Section.MOVIES, Section.SEARCH, Section.SETTINGS).forEach { entry ->
                            val library = entry == Section.MOVIES
                            val selected = if (library) s.section in listOf(Section.MOVIES, Section.SERIES, Section.FAVORITES) else s.section == entry
                            NavigationBarItem(selected, onClick = { if (library) libraryMenu = true else navigate(entry) },
                                icon = { Icon(entry.icon(), null) }, label = { Text(if (library) "Library" else entry.label, maxLines = 1) }, modifier = Modifier.testTag(if (library) "nav_LIBRARY" else "nav_${entry.name}").focusRing())
                        }
                    }
                    DropdownMenu(libraryMenu, { libraryMenu = false }) {
                        listOf(Section.MOVIES, Section.SERIES, Section.FAVORITES).forEach { entry ->
                            DropdownMenuItem(modifier = Modifier.testTag("nav_${entry.name}"), text = { Text(entry.label) }, onClick = { libraryMenu = false; navigate(entry) })
                        }
                    }
                }
            }
        }
    }
}

private data class HomeCollections(val movies: List<CatalogItem> = emptyList(), val series: List<CatalogItem> = emptyList(), val live: List<CatalogItem> = emptyList())

@Composable private fun HomeDashboard(s: AppState, select: (CatalogItem) -> Unit, play: (CatalogItem) -> Unit,
    toggle: (CatalogItem) -> Unit, retry: () -> Unit) {
    val favorites = remember(s.favorites) { s.favorites.map { it.key }.toSet() }
    val collections by produceState(HomeCollections(), s.catalog) {
        value = withContext(Dispatchers.Default) {
            HomeCollections(s.catalog.filter { it.kind == ContentKind.MOVIE }.sortedByDescending { it.added },
                s.catalog.filter { it.kind == ContentKind.SERIES }.sortedByDescending { it.added },
                s.catalog.filter { it.kind == ContentKind.LIVE })
        }
    }
    val movies = collections.movies
    val series = collections.series
    val live = collections.live
    val heroItems = remember(movies, series, live) { (movies.take(8) + series.take(8) + live.take(8)).take(8) }
    var featured by rememberSaveable { mutableIntStateOf(0) }
    var heroFocused by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val animationsAllowed = remember { Settings.Global.getFloat(context.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) > 0 }
    LaunchedEffect(s.appearance.heroRotation, s.appearance.motion, heroItems, heroFocused) {
        if (s.appearance.heroRotation && s.appearance.motion && animationsAllowed && !heroFocused && heroItems.size > 1)
            while (true) { delay(12_000); featured = (featured + 1) % heroItems.size }
    }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(24.dp)) {
        if (s.busy && s.catalog.isEmpty()) item { LoadingTiles() }
        s.error?.let { message -> item { InlineFailure(message, retry) } }
        if (!s.busy && s.catalog.isEmpty() && s.error == null) item { EmptyLibrary("Your library is ready", "Refresh to load content from your provider.", retry) }
        heroItems.getOrNull(featured.coerceIn(0, (heroItems.size - 1).coerceAtLeast(0)))?.let { featuredItem -> item(key = "hero") {
            Hero(featuredItem, favorites.contains(featuredItem.key), { select(featuredItem) }, { play(featuredItem) }, { toggle(featuredItem) },
                Modifier.onFocusChanged { heroFocused = it.hasFocus })
        } }
        val continuing = s.history.filter { it.item.kind != ContentKind.LIVE && !it.completed && it.position > 0 }
        if (continuing.isNotEmpty() && "Continue watching" !in s.appearance.hiddenRows) item(key = "continue") {
            MediaRow("Continue watching", continuing.map { it.item }, favorites, select, toggle, continuing.associateBy { it.item.key })
        }
        val recent = s.history.filter { it.item.kind == ContentKind.LIVE }.map { it.item }
        if (recent.isNotEmpty() && "Recently watched channels" !in s.appearance.hiddenRows) item(key = "recent") {
            MediaRow("Recently watched channels", recent, favorites, select, toggle)
        }
        if (s.favorites.isNotEmpty() && "Favorites" !in s.appearance.hiddenRows) item(key = "favorites") {
            MediaRow("Favorites", s.favorites, favorites, select, toggle)
        }
        if (live.isNotEmpty() && "Live TV" !in s.appearance.hiddenRows) item(key = "live") { MediaRow("Live TV", live, favorites, select, toggle) }
        if (movies.isNotEmpty() && "Movies" !in s.appearance.hiddenRows) item(key = "movies") { MediaRow(if (movies.any { it.added > 0 }) "Recently added movies" else "Movies", movies, favorites, select, toggle) }
        if (series.isNotEmpty() && "Series" !in s.appearance.hiddenRows) item(key = "series") { MediaRow("Series", series, favorites, select, toggle) }
        item { TextButton(retry, Modifier.padding(horizontal = 16.dp).focusRing()) { Text("Refresh library") } }
    }
}

@Composable private fun Hero(item: CatalogItem, favorite: Boolean, details: () -> Unit, play: () -> Unit, toggle: () -> Unit, modifier: Modifier) {
    BoxWithConstraints(modifier.fillMaxWidth().padding(horizontal = 20.dp).clip(RoundedCornerShape(24.dp)).background(Panel)) {
        val wide = maxWidth > 600.dp
        val height = if (wide) 330.dp else 320.dp
        AsyncImage(item.backdrop?.takeIf { it.isNotBlank() } ?: item.image, contentDescription = null,
            modifier = Modifier.matchParentSize(), contentScale = ContentScale.Crop)
        Box(Modifier.matchParentSize().background(Brush.verticalGradient(listOf(Color(0x33080B12), Color(0xEE080B12)))))
        Column(Modifier.fillMaxWidth().heightIn(min = height).padding(if (wide) 32.dp else 24.dp), verticalArrangement = Arrangement.Bottom) {
            Text("FEATURED IN YOUR LIBRARY", color = CinemaTokens.Cyan, style = MaterialTheme.typography.labelMedium)
            Spacer(Modifier.height(10.dp))
            Text(item.name, color = CinemaTokens.Text, style = if (wide) MaterialTheme.typography.displaySmall else MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.ExtraBold, maxLines = 3, overflow = TextOverflow.Ellipsis)
            Text(listOfNotNull(item.kind.label, item.year, item.genre, item.rating?.let { "Rating $it" }).joinToString("  ·  "),
                color = CinemaTokens.Secondary, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(vertical = 12.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(play, Modifier.heightIn(min = 48.dp).focusRing()) { Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(6.dp)); Text(if (item.kind == ContentKind.SERIES) "Episodes" else "Play now") }
                OutlinedButton(details, Modifier.heightIn(min = 48.dp).focusRing(), colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)) { Text("More details") }
                IconButton(toggle, Modifier.size(48.dp).focusRing()) { Icon(Icons.Default.Favorite, if (favorite) "Remove from favorites" else "Add to favorites", tint = if (favorite) CinemaTokens.Accent else Color.White) }
            }
        }
    }
}

@Composable private fun MediaRow(title: String, items: List<CatalogItem>, favorites: Set<String>, select: (CatalogItem) -> Unit,
    toggle: (CatalogItem) -> Unit, progress: Map<String, WatchRecord> = emptyMap()) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(title, Modifier.padding(horizontal = 20.dp), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            items(items.take(20), key = { it.key }) { item ->
                PremiumCard(item, favorites.contains(item.key), progress[item.key], Modifier.width(if (item.kind == ContentKind.LIVE) 216.dp else 152.dp), { select(item) }, { toggle(item) })
            }
        }
    }
}

@Composable private fun DiscoveryScreen(s: AppState, search: (String) -> Unit, category: (String) -> Unit, sort: (CatalogSort) -> Unit,
    select: (CatalogItem) -> Unit, toggle: (CatalogItem) -> Unit, retry: () -> Unit) {
    val keyboard = LocalSoftwareKeyboardController.current
    val focus = LocalFocusManager.current
    var sorting by remember { mutableStateOf(false) }
    val favorites = remember(s.favorites) { s.favorites.map { it.key }.toSet() }
    val history = remember(s.history) { s.history.associateBy { it.item.key } }
    val results by produceState<List<CatalogItem>?>(null, s.catalog, s.search, s.category, s.sort) {
        if (s.search.isNotBlank()) delay(180)
        value = withContext(Dispatchers.Default) { CatalogQuery.apply(s.catalog, s.search, s.category, s.sort) }
    }
    val shown = results.orEmpty()
    val grid = rememberLazyGridState()
    var lastFocus by rememberSaveable(s.section.name) { mutableStateOf<String?>(null) }
    val requester = remember { FocusRequester() }
    val input = LocalInputModeManager.current
    LaunchedEffect(s.section) {
        if (lastFocus != null && input.inputMode == androidx.compose.ui.input.InputMode.Keyboard) {
            delay(150); runCatching { requester.requestFocus() }
        }
    }
    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(s.search, search, Modifier.fillMaxWidth(), singleLine = true,
            label = { Text(if (s.section == Section.SEARCH) "Search your library" else "Search ${s.section.label.lowercase()}") },
            leadingIcon = { Icon(Icons.Default.Search, null) }, trailingIcon = { if (s.search.isNotBlank()) TextButton({ search("") }) { Text("Clear") } },
            shape = RoundedCornerShape(16.dp), keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { keyboard?.hide(); focus.clearFocus() }))
        if (s.categories.isNotEmpty()) LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            item { FilterChip(s.category.isEmpty(), { category("") }, { Text("All categories") }, modifier = Modifier.focusRing()) }
            items(s.categories, key = { it.id }) { c -> FilterChip(s.category == c.id, { category(c.id) }, { Text(c.name) }, modifier = Modifier.focusRing()) }
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("${shown.size} ${if (s.section == Section.LIVE) { if (shown.size == 1) "channel" else "channels" } else { if (shown.size == 1) "title" else "titles" }}", Modifier.weight(1f), color = Muted, style = MaterialTheme.typography.bodySmall)
            Box {
                TextButton({ sorting = true }, Modifier.focusRing()) { Text(s.sort.label) }
                DropdownMenu(sorting, { sorting = false }) {
                    CatalogSort.entries.filter { it != CatalogSort.RATING || s.catalog.any { item -> item.rating != null } }.forEach { choice ->
                        DropdownMenuItem(text = { Text(choice.label) }, onClick = { sorting = false; sort(choice) })
                    }
                }
            }
            TextButton(retry, Modifier.focusRing()) { Text("Refresh") }
        }
        s.error?.let { InlineFailure(it, retry) }
        if (s.busy && s.catalog.isEmpty()) LoadingTiles()
        else if (results == null) LinearProgressIndicator(Modifier.fillMaxWidth())
        else if (shown.isEmpty()) EmptyLibrary(if (s.search.isNotBlank()) "No matching titles" else if (s.section == Section.FAVORITES) "Keep your favorites here" else "No titles available",
            if (s.section == Section.FAVORITES) "Open a title and add it to favorites. Long-press a card to save it quickly." else "Try another search or category.", retry)
        else LazyVerticalGrid(GridCells.Adaptive(if (s.section == Section.LIVE) 220.dp else 145.dp), Modifier.weight(1f), state = grid,
            horizontalArrangement = Arrangement.spacedBy(14.dp), verticalArrangement = Arrangement.spacedBy(20.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
            items(shown, key = { it.key }) { item ->
                PremiumCard(item, favorites.contains(item.key), history[item.key],
                    Modifier.then(if (item.key == lastFocus) Modifier.focusRequester(requester) else Modifier).onFocusChanged { if (it.isFocused) lastFocus = item.key },
                    { select(item) }, { toggle(item) })
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable fun PremiumCard(item: CatalogItem, favorite: Boolean, progress: WatchRecord?, modifier: Modifier = Modifier, select: () -> Unit, toggle: () -> Unit) {
    val landscape = LocalConfiguration.current.screenWidthDp >= 840
    Column(modifier.testTag("card_${item.key}").focusRing().clip(RoundedCornerShape(14.dp)).background(Panel)
        .combinedClickable(onClick = select, onLongClick = toggle, onLongClickLabel = if (favorite) "Remove from favorites" else "Add to favorites")
        .semantics(mergeDescendants = true) {}, verticalArrangement = Arrangement.spacedBy(0.dp)) {
        Box {
            Artwork(if (landscape && !item.backdrop.isNullOrBlank()) item.copy(image = item.backdrop) else item,
                Modifier.fillMaxWidth().aspectRatio(if (item.kind == ContentKind.LIVE || landscape) 16f / 9 else 2f / 3))
            if (favorite) Icon(Icons.Default.Favorite, "Favorite", Modifier.align(Alignment.TopEnd).padding(8.dp).size(20.dp), tint = CinemaTokens.Accent)
            if (item.kind == ContentKind.LIVE) Text("LIVE", Modifier.align(Alignment.BottomStart).padding(8.dp).background(Color(0xE6080B12), RoundedCornerShape(4.dp)).padding(horizontal = 7.dp, vertical = 3.dp),
                color = CinemaTokens.Live, style = MaterialTheme.typography.labelSmall)
        }
        if (progress != null && progress.duration > 0 && item.kind != ContentKind.LIVE)
            LinearProgressIndicator(progress = { (progress.position.toFloat() / progress.duration).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth().height(3.dp))
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(item.name, maxLines = 2, minLines = 2, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.titleSmall)
            Text(listOfNotNull(item.year, item.rating?.let { "★ $it" }).joinToString("  ·  ").ifEmpty { item.kind.label }, color = Muted, style = MaterialTheme.typography.labelMedium, maxLines = 1)
        }
    }
}
@Composable private fun LoadingTiles() {
    Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        LinearProgressIndicator(Modifier.fillMaxWidth().semantics { contentDescription = "Loading library" })
        repeat(2) { Box(Modifier.fillMaxWidth().height(100.dp).clip(RoundedCornerShape(14.dp)).background(Panel)) }
    }
}
@Composable private fun EmptyLibrary(title: String, description: String, retry: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(title, style = MaterialTheme.typography.titleLarge); Text(description, color = Muted); Action("Refresh library", onClick = retry)
    }
}
@Composable private fun InlineFailure(message: String, retry: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        ErrorMessage(message); TextButton(retry, Modifier.focusRing()) { Text("Try again") }
    }
}
