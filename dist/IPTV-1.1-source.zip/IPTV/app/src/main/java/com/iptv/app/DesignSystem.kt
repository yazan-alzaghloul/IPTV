package com.iptv.app

import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.activity.compose.LocalActivity
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density

object CinemaTokens {
    val Background = Color(0xFF080B12)
    val Navigation = Color(0xFF111827)
    val Card = Color(0xFF1B2433)
    val Accent = Color(0xFFB9BCFF)
    val Cyan = Color(0xFF67E8F9)
    val Text = Color(0xFFF9FAFB)
    val Secondary = Color(0xFFB0B9C8)
    val Positive = Color(0xFF86EFAC)
    val Live = Color(0xFFFF8A8A)
}
val Ink: Color @Composable get() = MaterialTheme.colorScheme.background
val Panel: Color @Composable get() = MaterialTheme.colorScheme.surface
val Sky: Color @Composable get() = MaterialTheme.colorScheme.primary
val Muted: Color @Composable get() = MaterialTheme.colorScheme.onSurfaceVariant

@Composable fun IptvTheme(appearance: Appearance = Appearance(), content: @Composable () -> Unit) {
    val light = appearance.theme == "light"
    val accent = if (light) { if (appearance.accent == "cyan") Color(0xFF006875) else Color(0xFF4648A8) }
        else if (appearance.accent == "cyan") CinemaTokens.Cyan else CinemaTokens.Accent
    val colors = if (light) lightColorScheme(primary = accent, onPrimary = Color.White,
        background = Color(0xFFF4F5FA), surface = Color.White, surfaceVariant = Color(0xFFE6E9F0),
        onSurface = Color(0xFF111827), onBackground = Color(0xFF111827), onSurfaceVariant = Color(0xFF455267),
        secondaryContainer = Color(0xFFE0E2FF), onSecondaryContainer = Color(0xFF20224F))
    else darkColorScheme(primary = accent, onPrimary = CinemaTokens.Background,
        background = if (appearance.highContrast) Color.Black else CinemaTokens.Background,
        surface = CinemaTokens.Card, surfaceVariant = CinemaTokens.Navigation,
        onSurface = CinemaTokens.Text, onBackground = CinemaTokens.Text,
        onSurfaceVariant = if (appearance.highContrast) Color.White else CinemaTokens.Secondary,
        secondary = CinemaTokens.Cyan, secondaryContainer = Color(0xFF303253), onSecondaryContainer = CinemaTokens.Text,
        error = Color(0xFFFFB4AB))
    val activity = LocalActivity.current
    SideEffect {
        activity?.window?.let { window ->
            @Suppress("DEPRECATION")
            window.statusBarColor = colors.background.toArgb()
            @Suppress("DEPRECATION")
            window.navigationBarColor = colors.background.toArgb()
            androidx.core.view.WindowInsetsControllerCompat(window, window.decorView).apply {
                isAppearanceLightStatusBars = light
                isAppearanceLightNavigationBars = light
            }
        }
    }
    val density = LocalDensity.current
    CompositionLocalProvider(LocalDensity provides Density(density.density, density.fontScale * appearance.fontScale)) {
        MaterialTheme(colorScheme = colors, typography = Typography(), content = content)
    }
}
