package com.iptv.app

import android.app.Application
import androidx.compose.runtime.*
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.*

enum class Section(val label: String, val kind: ContentKind?) {
    LIVE("Live TV", ContentKind.LIVE), MOVIES("Movies", ContentKind.MOVIE), SERIES("Series", ContentKind.SERIES), FAVORITES("Favorites", null)
}
data class AppState(
    val restoring: Boolean = true, val signedIn: Boolean = false, val busy: Boolean = false,
    val error: String? = null, val section: Section = Section.LIVE,
    val categories: List<Category> = emptyList(), val catalog: List<CatalogItem> = emptyList(),
    val category: String = "", val search: String = "", val favorites: List<CatalogItem> = emptyList(),
    val selected: CatalogItem? = null, val details: ContentDetails? = null, val guide: List<Programme> = emptyList(),
    val detailBusy: Boolean = false, val detailError: String? = null
)
class AppViewModel(application: Application) : AndroidViewModel(application) {
    private val provider: ProviderRepository = XtreamRepository()
    private val credentialsStore: CredentialStore = SecureCredentialStore(application)
    private val library: LibraryRepository = LocalLibrary(PreferenceValues(application))
    private var credentials: Credentials? = null
    var state by mutableStateOf(AppState()); private set
    private var catalogJob: Job? = null
    private var detailJob: Job? = null
    init {
        viewModelScope.launch {
            try {
                val saved = withContext(Dispatchers.IO) { credentialsStore.read() }
                if (saved != null) {
                    credentials = saved
                    state = state.copy(restoring = false, signedIn = true, favorites = library.favorites(saved))
                    loadCatalog()
                } else state = state.copy(restoring = false)
            } catch (_: Exception) {
                withContext(Dispatchers.IO) { runCatching { credentialsStore.clear(); library.clear() } }
                state = AppState(restoring = false, error = "Saved login could not be unlocked. Please sign in again.")
            }
        }
    }
    fun login(host: String, port: String, scheme: String, username: String, password: String) {
        if (state.busy) return
        state = state.copy(busy = true, error = null)
        viewModelScope.launch {
            try {
                val account = LoginInput.normalize(host, port, scheme, username, password)
                provider.validate(account)
                withContext(Dispatchers.IO) { credentialsStore.save(account) }
                credentials = account
                state = AppState(restoring = false, signedIn = true, favorites = library.favorites(account))
                loadCatalog()
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { state = state.copy(busy = false, error = friendly(e)) }
        }
    }
    fun selectSection(section: Section) {
        if (state.section == section) return
        detailJob?.cancel()
        state = state.copy(section = section, selected = null, search = "", category = "", error = null)
        loadCatalog()
    }
    fun loadCatalog() {
        catalogJob?.cancel()
        val c = credentials ?: return
        val kind = state.section.kind
        if (kind == null) { state = state.copy(catalog = library.favorites(c), categories = emptyList(), busy = false); return }
        state = state.copy(busy = true, error = null, catalog = emptyList(), categories = emptyList())
        catalogJob = viewModelScope.launch {
            try {
                provider.validate(c)
                supervisorScope {
                    // Categories are optional; a provider category failure must not hide playable content.
                    val categories = async { try { provider.categories(c, kind) } catch (e: CancellationException) { throw e } catch (_: Exception) { emptyList() } }
                    val items = provider.catalog(c, kind)
                    state = state.copy(catalog = items, categories = categories.await(), busy = false)
                }
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { state = state.copy(busy = false, error = friendly(e)) }
        }
    }
    fun search(value: String) { state = state.copy(search = value) }
    fun category(value: String) { state = state.copy(category = value) }
    fun select(item: CatalogItem) {
        detailJob?.cancel()
        val c = credentials ?: return
        state = state.copy(selected = item, details = null, guide = emptyList(), detailBusy = true, detailError = null)
        detailJob = viewModelScope.launch {
            try {
                if (item.kind == ContentKind.LIVE) {
                    state = state.copy(guide = provider.guide(c, item.id), detailBusy = false)
                } else state = state.copy(details = provider.details(c, item), detailBusy = false)
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { state = state.copy(detailBusy = false, detailError = friendly(e)) }
        }
    }
    fun closeDetails() { detailJob?.cancel(); state = state.copy(selected = null, details = null, guide = emptyList(), detailError = null) }
    fun toggle(item: CatalogItem) {
        val c = credentials ?: return
        library.toggle(c, item)
        val favorites = library.favorites(c)
        state = state.copy(favorites = favorites, catalog = if (state.section == Section.FAVORITES) favorites else state.catalog)
    }
    fun playbackItem(item: CatalogItem): CatalogItem =
        if (item.kind == ContentKind.MOVIE) item.copy(extension = state.details?.extension ?: item.extension) else item
    fun signOut() {
        catalogJob?.cancel(); detailJob?.cancel()
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) { credentialsStore.clear(); library.clear() }
                credentials = null
                state = AppState(restoring = false)
            } catch (_: Exception) { state = state.copy(error = "Could not clear saved data. Try signing out again.") }
        }
    }
    private fun friendly(e: Exception): String = when (e) {
        is ProviderException, is IllegalArgumentException -> e.message ?: "Check your details and try again."
        else -> "Could not complete this request. Check your connection and try again."
    }
}
