package com.iptv.app

import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.*
import android.widget.*
import android.app.Activity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.*
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.session.MediaSession
import androidx.media3.ui.PlayerView
import com.google.gson.Gson

interface PlaybackEngine {
    val player: Player
    fun open(url: String, position: Long, live: Boolean)
    fun release()
}
@UnstableApi
class Media3Engine(context: android.content.Context) : PlaybackEngine {
    override val player = ExoPlayer.Builder(context)
        .setMediaSourceFactory(DefaultMediaSourceFactory(DefaultHttpDataSource.Factory()
            .setUserAgent("IPTV/1.0 Android").setConnectTimeoutMs(15_000).setReadTimeoutMs(30_000)
            .setAllowCrossProtocolRedirects(true)))
        .setAudioAttributes(AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(), true)
        .setHandleAudioBecomingNoisy(true).build()
    override fun open(url: String, position: Long, live: Boolean) {
        player.setMediaItem(MediaItem.fromUri(url))
        if (!live && position > 0) player.seekTo(position)
        player.prepare()
        player.playWhenReady = true
    }
    override fun release() = player.release()
}

@UnstableApi
class PlayerActivity : Activity() {
    private lateinit var item: CatalogItem
    private var credentials: Credentials? = null
    private lateinit var library: LibraryRepository
    private var engine: PlaybackEngine? = null
    private var session: MediaSession? = null
    private lateinit var video: PlayerView
    private lateinit var errorPanel: LinearLayout
    private lateinit var errorText: TextView
    private lateinit var header: LinearLayout
    private var useTransportStream = false
    private val handler = Handler(Looper.getMainLooper())
    private val checkpoint = object : Runnable {
        override fun run() { savePosition(); handler.postDelayed(this, 5_000) }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Media3 errors can include provider URLs containing credentials. Keep library logs off.
        androidx.media3.common.util.Log.setLogLevel(androidx.media3.common.util.Log.LOG_LEVEL_OFF)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        library = LocalLibrary(PreferenceValues(this))
        val decoded = runCatching { Gson().fromJson(intent.getStringExtra("item"), CatalogItem::class.java) }.getOrNull()
        if (decoded == null) { finish(); return }
        item = decoded
        credentials = runCatching { SecureCredentialStore(this).read() }.getOrNull()
        if (credentials == null) { finish(); return }
        useTransportStream = savedInstanceState?.getBoolean("transportStream") ?: false
        val frame = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        video = PlayerView(this).apply {
            keepScreenOn = true
            setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
            setShowSubtitleButton(true)
            setShowNextButton(false); setShowPreviousButton(false)
            setShowFastForwardButton(item.kind != ContentKind.LIVE)
            setShowRewindButton(item.kind != ContentKind.LIVE)
            controllerShowTimeoutMs = 4_000
        }
        frame.addView(video, FrameLayout.LayoutParams(-1, -1))
        header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(0xC00D1420.toInt())
            addView(Button(this@PlayerActivity).apply { text = "Back"; setOnClickListener { finish() } })
            addView(TextView(this@PlayerActivity).apply { text = item.name; textSize = 18f; setTextColor(Color.WHITE); setPadding(dp(16), 0, 0, 0) }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        frame.addView(header, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))
        errorPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(24), dp(24), dp(24))
            setBackgroundColor(0xEE0D1420.toInt())
            visibility = View.GONE
        }
        errorText = TextView(this).apply { textSize = 18f; setTextColor(Color.WHITE); gravity = Gravity.CENTER }
        errorPanel.addView(errorText)
        errorPanel.addView(Button(this).apply { text = "Retry playback"; setOnClickListener { open() } })
        if (item.kind == ContentKind.LIVE) errorPanel.addView(Button(this).apply {
            text = "Switch HLS / MPEG-TS"
            setOnClickListener { useTransportStream = !useTransportStream; open() }
        })
        errorPanel.addView(Button(this).apply { text = "Back to details"; setOnClickListener { finish() } })
        frame.addView(errorPanel, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER))
        video.setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { visible -> header.visibility = visible })
        setContentView(frame)
    }
    override fun onStart() {
        super.onStart()
        if (!::video.isInitialized || credentials == null) return
        val playback = Media3Engine(this)
        engine = playback
        video.player = playback.player
        session = MediaSession.Builder(this, playback.player).build()
        playback.player.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                errorText.text = when (error.errorCode) {
                    PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED, PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT ->
                        "Connection interrupted. Check your network, then retry."
                    PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS -> "The provider refused this stream. Check your subscription or try again later."
                    PlaybackException.ERROR_CODE_DECODING_FAILED, PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED ->
                        "This device cannot decode this stream. Try another title or audio track."
                    else -> "This stream is unavailable or unsupported. Retry or choose another title."
                }
                errorPanel.visibility = View.VISIBLE
                errorPanel.getChildAt(1).requestFocus()
            }
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED) {
                    credentials?.let { library.savePosition(it, item, 0, 0) }
                }
            }
        })
        open()
        video.requestFocus()
        video.showController()
        handler.postDelayed(checkpoint, 5_000)
    }
    private fun open() {
        val c = credentials ?: return
        val playback = engine ?: return
        val previous = playback.player.currentPosition.takeIf { it > 0 } ?: library.position(c, item)
        val base = XtreamRepository().streamUrl(c, item)
        val url = if (useTransportStream && item.kind == ContentKind.LIVE) base.removeSuffix("m3u8") + "ts" else base
        errorPanel.visibility = View.GONE
        playback.open(url, previous, item.kind == ContentKind.LIVE)
        video.requestFocus()
    }
    private fun savePosition() {
        val c = credentials ?: return
        val player = engine?.player ?: return
        if (player.playbackState == Player.STATE_ENDED) library.savePosition(c, item, 0, 0)
        else if (player.playbackState == Player.STATE_READY || player.currentPosition > 0)
            library.savePosition(c, item, player.currentPosition, player.duration)
    }
    override fun onStop() {
        handler.removeCallbacks(checkpoint)
        savePosition()
        session?.release(); session = null
        if (::video.isInitialized) video.player = null
        engine?.release(); engine = null
        super.onStop()
    }
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (::video.isInitialized && event.keyCode != KeyEvent.KEYCODE_BACK && errorPanel.visibility != View.VISIBLE && video.dispatchKeyEvent(event)) return true
        return super.dispatchKeyEvent(event)
    }
    override fun onSaveInstanceState(outState: Bundle) {
        outState.putBoolean("transportStream", useTransportStream)
        super.onSaveInstanceState(outState)
    }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
