package com.iptv.app

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.*
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.SubcomposeAsyncImage
import com.google.gson.Gson
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

val Ink = Color(0xFF0D1420)
val Panel = Color(0xFF17263B)
val Sky = Color(0xFF9AC9FF)
val Muted = Color(0xFFB6C4D7)
private val AppColors = darkColorScheme(primary = Sky, onPrimary = Ink, background = Ink, surface = Panel,
    onSurface = Color(0xFFF1F5FA), onBackground = Color(0xFFF1F5FA), onSurfaceVariant = Muted,
    surfaceVariant = Color(0xFF22354D), secondary = Sky, secondaryContainer = Color(0xFF22354D), onSecondaryContainer = Color(0xFFF1F5FA), error = Color(0xFFFFB4AB))

@Composable fun IptvTheme(content: @Composable () -> Unit) { MaterialTheme(colorScheme = AppColors, content = content) }

@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            IptvTheme {
                val vm: AppViewModel = viewModel()
                val state = vm.state
                Surface(Modifier.fillMaxSize(), color = Ink) {
                    when {
                        state.restoring -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                        !state.signedIn -> LoginScreen(state.busy, state.error, vm::login)
                        state.selected != null -> {
                            BackHandler { vm.closeDetails() }
                            DetailsScreen(state, vm::closeDetails, vm::toggle, { vm.select(state.selected) }) { item ->
                                startActivity(Intent(this, PlayerActivity::class.java).putExtra("item", Gson().toJson(vm.playbackItem(item))))
                            }
                        }
                        else -> CatalogScreen(state, vm::selectSection, vm::search, vm::category, vm::select, vm::loadCatalog, vm::signOut)
                    }
                }
            }
        }
    }
}

@Composable fun Modifier.focusRing(): Modifier {
    var focused by remember { mutableStateOf(false) }
    return onFocusChanged { focused = it.hasFocus }.border(if (focused) 3.dp else 0.dp,
        if (focused) Sky else Color.Transparent, RoundedCornerShape(12.dp))
}
@Composable fun Action(label: String, modifier: Modifier = Modifier, enabled: Boolean = true, primary: Boolean = false, onClick: () -> Unit) {
    val m = modifier.heightIn(min = 48.dp).focusRing()
    if (primary) Button(onClick, m, enabled = enabled, shape = RoundedCornerShape(12.dp)) { Text(label) }
    else OutlinedButton(onClick, m, enabled = enabled, shape = RoundedCornerShape(12.dp)) { Text(label) }
}

@Composable fun LoginScreen(busy: Boolean, error: String?, onLogin: (String, String, String, String, String) -> Unit) {
    var host by rememberSaveable { mutableStateOf("") }
    var port by rememberSaveable { mutableStateOf("") }
    var scheme by rememberSaveable { mutableStateOf("https") }
    var username by rememberSaveable { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var showPassword by remember { mutableStateOf(false) }
    val submit = { onLogin(host, port, scheme, username, password) }
    Box(Modifier.fillMaxSize().safeDrawingPadding().imePadding(), contentAlignment = Alignment.Center) {
        Column(Modifier.widthIn(max = 520.dp).fillMaxWidth().verticalScroll(rememberScrollState()).padding(24.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("IPTV", style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Bold, color = Sky)
            Text("Your channels. One place.", style = MaterialTheme.typography.headlineSmall)
            Text("Sign in with your IPTV provider’s Xtream account.", color = Muted)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                FilterChip(scheme == "https", { scheme = "https" }, { Text("HTTPS") }, modifier = Modifier.focusRing(), enabled = !busy)
                FilterChip(scheme == "http", { scheme = "http" }, { Text("HTTP") }, modifier = Modifier.focusRing(), enabled = !busy)
            }
            if (scheme == "http" || host.startsWith("http://", true)) Text("HTTP sends your login and video without encryption. Use HTTPS when your provider supports it.", style = MaterialTheme.typography.bodySmall, color = Muted)
            OutlinedTextField(host, { host = it }, Modifier.fillMaxWidth(), enabled = !busy, label = { Text("Host or provider URL") }, placeholder = { Text("provider.example or https://provider.example/path/") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Next))
            OutlinedTextField(port, { port = it }, Modifier.fillMaxWidth(), enabled = !busy, label = { Text("Port (optional)") }, supportingText = { Text("Leave blank to use the URL port or HTTP/HTTPS default.") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next))
            OutlinedTextField(username, { username = it }, Modifier.fillMaxWidth(), enabled = !busy, label = { Text("Username") }, singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next, autoCorrectEnabled = false))
            OutlinedTextField(password, { password = it }, Modifier.fillMaxWidth(), enabled = !busy, label = { Text("Password") }, singleLine = true,
                visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = { TextButton({ showPassword = !showPassword }, Modifier.focusRing()) { Text(if (showPassword) "Hide" else "Show") } },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Go), keyboardActions = KeyboardActions(onGo = { submit() }))
            error?.let { ErrorMessage(it) }
            Action(if (busy) "Connecting…" else "Connect", Modifier.fillMaxWidth(), enabled = !busy, primary = true, onClick = submit)
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            Text("Your login stays on this device. Channels and titles come from your subscription.", color = Muted, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable fun CatalogScreen(s: AppState, section: (Section) -> Unit, search: (String) -> Unit, category: (String) -> Unit,
    select: (CatalogItem) -> Unit, retry: () -> Unit, signOut: () -> Unit) {
    val focusManager = LocalFocusManager.current
    val keyboard = LocalSoftwareKeyboardController.current
    val changeSection: (Section) -> Unit = { entry ->
        focusManager.clearFocus(); keyboard?.hide(); section(entry)
    }
    var confirmSignOut by remember { mutableStateOf(false) }
    if (confirmSignOut) AlertDialog(onDismissRequest = { confirmSignOut = false }, title = { Text("Sign out?") },
        text = { Text("This removes your saved login, favorites, and playback progress from this device.") },
        confirmButton = { TextButton({ confirmSignOut = false; signOut() }, Modifier.focusRing()) { Text("Sign out") } },
        dismissButton = { TextButton({ confirmSignOut = false }, Modifier.focusRing()) { Text("Cancel") } })
    BoxWithConstraints(Modifier.fillMaxSize().safeDrawingPadding()) {
        val wide = maxWidth >= 840.dp
        Row(Modifier.fillMaxSize()) {
            if (wide) Column(Modifier.width(164.dp).fillMaxHeight().background(Panel).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("IPTV", Modifier.padding(vertical = 16.dp), style = MaterialTheme.typography.headlineMedium, color = Sky, fontWeight = FontWeight.Bold)
                Section.entries.forEach { entry -> Action(entry.label, Modifier.fillMaxWidth(), primary = s.section == entry) { changeSection(entry) } }
                Spacer(Modifier.weight(1f))
                Action("Sign out", Modifier.fillMaxWidth()) { confirmSignOut = true }
            }
            Column(Modifier.weight(1f).fillMaxHeight().padding(horizontal = if (wide) 28.dp else 16.dp)) {
                Row(Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(s.section.label, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                        Text(if (s.section == Section.FAVORITES) "Your saved channels and titles" else "From your provider’s library", color = Muted, style = MaterialTheme.typography.bodySmall)
                    }
                    if (!wide) TextButton({ confirmSignOut = true }, Modifier.focusRing()) { Text("Sign out") }
                }
                if (!wide) Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Section.entries.forEach { entry -> FilterChip(s.section == entry, { changeSection(entry) }, { Text(entry.label) }, modifier = Modifier.focusRing()) }
                }
                OutlinedTextField(s.search, search, Modifier.fillMaxWidth().padding(vertical = 8.dp), label = { Text("Search ${s.section.label.lowercase()}") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { focusManager.clearFocus(); keyboard?.hide() }),
                    trailingIcon = { if (s.search.isNotEmpty()) TextButton({ search("") }, Modifier.focusRing()) { Text("Clear") } })
                if (s.categories.isNotEmpty()) androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    item { FilterChip(s.category.isEmpty(), { category("") }, { Text("All categories") }, modifier = Modifier.focusRing()) }
                    items(s.categories.size, key = { s.categories[it].id }) { i ->
                        val c = s.categories[i]
                        FilterChip(s.category == c.id, { category(c.id) }, { Text(c.name) }, modifier = Modifier.focusRing())
                    }
                }
                val shown = remember(s.catalog, s.search, s.category) {
                    s.catalog.filter { (s.category.isEmpty() || it.categoryId == s.category) && it.name.contains(s.search.trim(), true) }
                }
                when {
                    s.busy -> Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                    s.error != null -> Column(Modifier.padding(vertical = 24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) { ErrorMessage(s.error); Action("Try again", onClick = retry) }
                    shown.isEmpty() -> Column(Modifier.padding(vertical = 32.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(if (s.search.isNotBlank()) "No matching titles" else if (s.section == Section.FAVORITES) "Keep your favorites here" else "No titles available", style = MaterialTheme.typography.titleLarge)
                        Text(if (s.section == Section.FAVORITES) "Open a channel or title and choose Add to favorites." else "Try another category or refresh your provider’s library.", color = Muted)
                        if (s.section != Section.FAVORITES) Action("Refresh", onClick = retry)
                    }
                    else -> {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text("${shown.size} ${if (s.section == Section.LIVE) { if (shown.size == 1) "channel" else "channels" } else { if (shown.size == 1) "title" else "titles" }}", Modifier.weight(1f), color = Muted, style = MaterialTheme.typography.bodySmall)
                            if (s.section != Section.FAVORITES) TextButton(retry, Modifier.focusRing()) { Text("Refresh") }
                        }
                        key(s.section, s.category, s.search) {
                            LazyVerticalGrid(GridCells.Adaptive(if (wide) 185.dp else 145.dp), Modifier.weight(1f), contentPadding = PaddingValues(bottom = 24.dp, top = 8.dp),
                                horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                items(shown, key = { it.key }) { item -> CatalogCard(item, s.favorites.any { it.key == item.key }) { focusManager.clearFocus(); keyboard?.hide(); select(item) } }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable fun CatalogCard(item: CatalogItem, favorite: Boolean, select: () -> Unit) {
    OutlinedCard(onClick = select, modifier = Modifier.fillMaxWidth().focusRing(), shape = RoundedCornerShape(12.dp), colors = CardDefaults.outlinedCardColors(containerColor = Panel)) {
        Artwork(item, Modifier.fillMaxWidth().height(if (item.kind == ContentKind.LIVE) 100.dp else 160.dp))
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(item.name, maxLines = 2, minLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleSmall)
            Text((if (favorite) "★  " else "") + item.kind.label, color = Sky, style = MaterialTheme.typography.labelMedium)
        }
    }
}
@Composable fun Artwork(item: CatalogItem, modifier: Modifier) {
    val fallback: @Composable () -> Unit = {
        Box(Modifier.fillMaxSize().background(Panel), contentAlignment = Alignment.Center) {
            Text(if (item.kind == ContentKind.LIVE) "LIVE" else item.name.take(1).uppercase(), color = Sky, style = MaterialTheme.typography.headlineMedium)
        }
    }
    SubcomposeAsyncImage(model = item.image, contentDescription = null, modifier = modifier.clip(RoundedCornerShape(8.dp)),
        contentScale = if (item.kind == ContentKind.LIVE) ContentScale.Fit else ContentScale.Crop,
        loading = { fallback() }, error = { fallback() })
}

@Composable fun DetailsScreen(s: AppState, back: () -> Unit, toggle: (CatalogItem) -> Unit, retry: () -> Unit, play: (CatalogItem) -> Unit) {
    val item = s.selected ?: return
    var now by remember { mutableLongStateOf(System.currentTimeMillis() / 1000) }
    LaunchedEffect(item.key) { while (true) { now = System.currentTimeMillis() / 1000; kotlinx.coroutines.delay(30_000) } }
    val current = s.guide.firstOrNull { it.start <= now && it.end > now }
    val next = s.guide.firstOrNull { it.start > now }
    LazyColumn(Modifier.fillMaxSize().safeDrawingPadding().padding(horizontal = 24.dp), verticalArrangement = Arrangement.spacedBy(16.dp), contentPadding = PaddingValues(vertical = 16.dp)) {
        item { Action("Back to ${s.section.label}", onClick = back) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(20.dp), verticalAlignment = Alignment.Top) {
                Artwork(item, Modifier.widthIn(max = 160.dp).weight(0.32f).height(170.dp))
                Column(Modifier.weight(0.68f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(item.kind.label.uppercase(), style = MaterialTheme.typography.labelLarge, color = Sky)
                    Text(item.name, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    s.details?.metadata?.takeIf { it.isNotBlank() }?.let { Text(it, color = Muted) }
                }
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (item.kind != ContentKind.SERIES) Action(if (item.kind == ContentKind.LIVE) "Watch live" else "Watch / resume", Modifier.fillMaxWidth(), primary = true) { play(item) }
                Action(if (s.favorites.any { it.key == item.key }) "Remove from favorites" else "Add to favorites", Modifier.fillMaxWidth()) { toggle(item) }
            }
        }
        if (s.detailBusy) item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
        s.detailError?.let { message -> item { ErrorMessage(message); Action("Retry details", onClick = retry) } }
        if (item.kind == ContentKind.LIVE) item {
            Text("On this channel", style = MaterialTheme.typography.titleLarge)
            ProgrammeRow("Now", current)
            ProgrammeRow("Next", next)
        }
        s.details?.description?.takeIf { it.isNotBlank() }?.let { description -> item { Text(description, style = MaterialTheme.typography.bodyLarge) } }
        if (item.kind == ContentKind.SERIES && !s.detailBusy) {
            if (s.details?.episodes.isNullOrEmpty()) item { Text("No episodes available from this provider.", color = Muted) }
            items(s.details?.episodes ?: emptyList(), key = { it.item.key }) { ep ->
                Action("S${ep.season} · E${ep.number}   ${ep.item.name}", Modifier.fillMaxWidth()) { play(ep.item) }
            }
        }
    }
}
@Composable fun ProgrammeRow(label: String, programme: Programme?) {
    Column(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(label, color = Sky, style = MaterialTheme.typography.labelLarge)
        Text(programme?.title ?: "Program information unavailable")
        programme?.let {
            val format = SimpleDateFormat("HH:mm", Locale.getDefault())
            Text("${format.format(Date(it.start * 1000))} – ${format.format(Date(it.end * 1000))}", color = Muted)
        }
    }
}
@Composable fun ErrorMessage(message: String) { Text(message, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium) }
