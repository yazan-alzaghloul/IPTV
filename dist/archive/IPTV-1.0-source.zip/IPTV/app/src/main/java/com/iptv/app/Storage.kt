package com.iptv.app

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import com.google.gson.Gson
import java.security.KeyStore
import java.security.MessageDigest
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

interface CredentialStore {
    fun read(): Credentials?
    fun save(credentials: Credentials)
    fun clear()
}
class SecureCredentialStore(context: Context) : CredentialStore {
    private val prefs = context.getSharedPreferences("account_vault", Context.MODE_PRIVATE)
    private val alias = "iptv.account.v1"
    private fun key(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(alias, null) as? SecretKey)?.let { return it }
        return KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore").apply {
            init(KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build())
        }.generateKey()
    }
    override fun read(): Credentials? {
        val encoded = prefs.getString("sealed", null) ?: return null
        val packed = Base64.decode(encoded, Base64.NO_WRAP)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, packed.copyOfRange(0, 12)))
        return Gson().fromJson(cipher.doFinal(packed.copyOfRange(12, packed.size)).toString(Charsets.UTF_8), Credentials::class.java)
    }
    override fun save(credentials: Credentials) {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.ENCRYPT_MODE, key()) }
        val packed = cipher.iv + cipher.doFinal(Gson().toJson(credentials).toByteArray(Charsets.UTF_8))
        check(prefs.edit().putString("sealed", Base64.encodeToString(packed, Base64.NO_WRAP)).commit()) { "Account could not be saved." }
    }
    override fun clear() {
        check(prefs.edit().clear().commit()) { "Saved account could not be cleared." }
        KeyStore.getInstance("AndroidKeyStore").apply { load(null); deleteEntry(alias) }
    }
}
interface KeyValueStore {
    fun get(key: String): String?
    fun put(key: String, value: String)
    fun clear()
}
class PreferenceValues(context: Context) : KeyValueStore {
    private val prefs = context.getSharedPreferences("local_library", Context.MODE_PRIVATE)
    override fun get(key: String) = prefs.getString(key, null)
    override fun put(key: String, value: String) { prefs.edit().putString(key, value).apply() }
    override fun clear() { check(prefs.edit().clear().commit()) }
}
interface LibraryRepository {
    fun favorites(c: Credentials): List<CatalogItem>
    fun toggle(c: Credentials, item: CatalogItem)
    fun position(c: Credentials, item: CatalogItem): Long
    fun savePosition(c: Credentials, item: CatalogItem, position: Long, duration: Long)
    fun clear()
}
class LocalLibrary(private val store: KeyValueStore) : LibraryRepository {
    private val gson = Gson()
    private fun scope(c: Credentials) = MessageDigest.getInstance("SHA-256").digest(
        gson.toJson(c).toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
    override fun favorites(c: Credentials): List<CatalogItem> = runCatching {
        gson.fromJson(store.get("${scope(c)}.favorites") ?: "[]", Array<CatalogItem>::class.java).toList()
    }.getOrDefault(emptyList())
    override fun toggle(c: Credentials, item: CatalogItem) {
        val current = favorites(c)
        val updated = if (current.any { it.key == item.key }) current.filterNot { it.key == item.key } else current + item
        store.put("${scope(c)}.favorites", gson.toJson(updated))
    }
    override fun position(c: Credentials, item: CatalogItem): Long = if (item.kind == ContentKind.LIVE) 0L
        else store.get("${scope(c)}.position.${item.key}")?.toLongOrNull()?.coerceAtLeast(0) ?: 0L
    override fun savePosition(c: Credentials, item: CatalogItem, position: Long, duration: Long) {
        if (item.kind == ContentKind.LIVE) return
        val value = if (duration > 0 && position >= duration - 10_000) 0L else position.coerceAtLeast(0)
        store.put("${scope(c)}.position.${item.key}", value.toString())
    }
    override fun clear() = store.clear()
}
