package com.iptv.app

import android.content.Context
import android.view.KeyEvent
import android.view.ViewGroup
import androidx.compose.ui.test.*
import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.test.junit4.createEmptyComposeRule
import androidx.test.core.app.ActivityScenario
import androidx.test.espresso.Espresso
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.runner.lifecycle.ActivityLifecycleMonitorRegistry
import androidx.test.runner.lifecycle.Stage
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.PlayerView
import okhttp3.mockwebserver.*
import okio.Buffer
import org.junit.*
import org.junit.Assert.*
import org.junit.runner.RunWith
import java.util.Base64
import java.util.concurrent.atomic.AtomicBoolean

@RunWith(AndroidJUnit4::class)
@UnstableApi
class AppFlowTest {
    @get:Rule val compose = createEmptyComposeRule()
    private val instrumentation get() = InstrumentationRegistry.getInstrumentation()
    private val context get() = instrumentation.targetContext
    private lateinit var server: MockWebServer
    private lateinit var scenario: ActivityScenario<MainActivity>
    private val failStream = AtomicBoolean(false)
    private val failCatalog = AtomicBoolean(false)
    private val video by lazy { instrumentation.context.assets.open("sample.mp4").use { it.readBytes() } }
    @Before fun setup() {
        SecureCredentialStore(context).clear(); LocalLibrary(PreferenceValues(context)).clear()
        server = MockWebServer()
        server.dispatcher = object : Dispatcher() {
            override fun dispatch(request: RecordedRequest): MockResponse {
                val url = request.requestUrl!!
                if (!url.encodedPath.endsWith("player_api.php")) {
                    if (failStream.get()) return MockResponse().setResponseCode(503)
                    if (url.encodedPath.endsWith(".m3u8")) return MockResponse().setHeader("Content-Type", "application/x-mpegURL").setBody("#EXTM3U\n#EXT-X-TARGETDURATION:10\n#EXT-X-MEDIA-SEQUENCE:0\n#EXTINF:10.0,\n/segment.ts\n")
                    val data = if (url.encodedPath.endsWith(".ts")) instrumentation.context.assets.open("sample.ts").use { it.readBytes() } else video
                    val start = request.getHeader("Range")?.substringAfter("bytes=")?.substringBefore('-')?.toIntOrNull() ?: 0
                    if (start >= data.size) return MockResponse().setResponseCode(416)
                    return MockResponse().setResponseCode(if (start > 0) 206 else 200)
                        .setHeader("Accept-Ranges", "bytes").setHeader("Content-Type", if (url.encodedPath.endsWith(".ts")) "video/mp2t" else "video/mp4")
                        .apply { if (start > 0) setHeader("Content-Range", "bytes $start-${data.size - 1}/${data.size}") }
                        .setBody(Buffer().write(data, start, data.size - start))
                }
                if (failCatalog.get()) return MockResponse().setResponseCode(503)
                val action = url.queryParameter("action")
                val now = System.currentTimeMillis() / 1000
                fun encoded(value: String) = Base64.getEncoder().encodeToString(value.toByteArray())
                val body = when (action) {
                    null -> """{"user_info":{"auth":1,"status":"Active"}}"""
                    "get_live_categories", "get_vod_categories", "get_series_categories" -> """[{"category_id":"1","category_name":"Test category"}]"""
                    "get_live_streams" -> """[{"stream_id":1,"name":"Fixture News","category_id":"1"}]"""
                    "get_vod_streams" -> """[{"stream_id":2,"name":"Fixture Movie","category_id":"1","container_extension":"mp4"}]"""
                    "get_series" -> """[{"series_id":3,"name":"Fixture Series","category_id":"1"}]"""
                    "get_vod_info" -> """{"info":{"plot":"Fixture movie description"},"movie_data":{"container_extension":"mp4"}}"""
                    "get_series_info" -> """{"info":{"plot":"Fixture series description"},"episodes":{"1":[{"id":4,"episode_num":1,"title":"Pilot","container_extension":"mp4"}]}}"""
                    "get_short_epg" -> """{"epg_listings":[{"title":"${encoded("News now")}","start_timestamp":"${now - 600}","stop_timestamp":"${now + 600}"},{"title":"${encoded("News next")}","start_timestamp":"${now + 600}","stop_timestamp":"${now + 1200}"}]}"""
                    else -> "[]"
                }
                return MockResponse().setHeader("Content-Type", "application/json").setBody(body)
            }
        }
        server.start()
        scenario = ActivityScenario.launch(MainActivity::class.java)
    }
    @After fun cleanup() {
        instrumentation.runOnMainSync {
            ActivityLifecycleMonitorRegistry.getInstance().getActivitiesInStage(Stage.RESUMED).filterIsInstance<PlayerActivity>().forEach { it.finish() }
        }
        scenario.close(); server.shutdown()
        SecureCredentialStore(context).clear(); LocalLibrary(PreferenceValues(context)).clear()
    }
    private fun login() {
        compose.waitUntil(10_000) { compose.onAllNodesWithText("Host or provider URL").fetchSemanticsNodes().isNotEmpty() }
        compose.onNodeWithText("Host or provider URL").performScrollTo().performTextInput(server.url("/service/").toString())
        compose.onNodeWithText("Username", substring = false).performScrollTo().performTextInput("fixture")
        compose.onNodeWithText("Password", substring = false).performScrollTo().performTextInput("fixture-password")
        Espresso.closeSoftKeyboard()
        compose.onNodeWithText("Connect", substring = false).performScrollTo().performClick()
        waitFor("Fixture News")
    }
    private fun waitFor(text: String) {
        try {
            compose.waitUntil(15_000) { compose.onAllNodesWithText(text).fetchSemanticsNodes().isNotEmpty() }
        } catch (e: ComposeTimeoutException) {
            capture("failure")
            java.io.File(context.filesDir, "screenshots/failure-tree.txt").writeText(compose.onRoot().printToString())
            throw e
        }
    }
    private fun back() { Espresso.pressBack(); compose.waitForIdle() }
    @Test fun loginValidationAndCatalogFavoritesEpisodesAndCleanup() {
        compose.onNodeWithText("Connect", substring = false).performScrollTo().performClick()
        waitFor("Enter your username and password.")
        login()
        capture("catalog")
        compose.onNodeWithText("Fixture News").performClick()
        waitFor("News now"); compose.onNodeWithText("News next").assertExists()
        capture("channel-details")
        compose.onNodeWithText("Add to favorites").performClick()
        back()
        compose.onNodeWithText("Favorites", substring = false).performClick()
        waitFor("Fixture News")
        compose.onNodeWithText("Fixture News").performClick()
        compose.onNodeWithText("Remove from favorites").performClick()
        back(); waitFor("Keep your favorites here")
        compose.onNodeWithText("Movies", substring = false).performClick(); waitFor("Fixture Movie")
        compose.onNodeWithText("Search movies").performTextInput("nonexistent")
        compose.onNodeWithText("Search movies").performImeAction()
        waitFor("No matching titles")
        compose.onNodeWithText("Clear", substring = false).performClick(); waitFor("Fixture Movie")
        compose.onNodeWithText("Fixture Movie").performClick(); waitFor("Fixture movie description")
        back()
        compose.onNodeWithText("Series", substring = false).performClick(); waitFor("Fixture Series")
        compose.onNodeWithText("Fixture Series").performClick(); waitFor("S1 · E1   Pilot")
        back()
        compose.onNodeWithText("Sign out", substring = false).performClick()
        compose.onAllNodesWithText("Sign out", substring = false).onLast().performClick()
        waitFor("Connect")
        assertNull(SecureCredentialStore(context).read())
        assertTrue(context.getSharedPreferences("local_library", Context.MODE_PRIVATE).all.isEmpty())
    }
    @Test fun savedCredentialsAreEncryptedAndRestored() {
        login()
        val credentials = SecureCredentialStore(context).read()!!
        assertEquals("fixture", credentials.username)
        val saved = context.getSharedPreferences("account_vault", Context.MODE_PRIVATE).all.toString()
        assertFalse(saved.contains("fixture-password")); assertFalse(saved.contains("fixture"))
        scenario.recreate(); waitFor("Fixture News")
    }
    @Test fun catalogFailureCanBeRetriedAndRemoteFocusWorks() {
        login()
        instrumentation.sendKeyDownUpSync(KeyEvent.KEYCODE_DPAD_DOWN)
        instrumentation.sendKeyDownUpSync(KeyEvent.KEYCODE_DPAD_RIGHT)
        compose.onAllNodes(isFocused()).assertCountEquals(1)
        Espresso.closeSoftKeyboard()
        compose.onNodeWithText("Fixture News").performSemanticsAction(SemanticsActions.RequestFocus) { it() }
        compose.onNodeWithText("Fixture News").assertIsFocused()
        capture("remote-focus")
        instrumentation.sendKeyDownUpSync(KeyEvent.KEYCODE_DPAD_CENTER)
        waitFor("Watch live")
        back()
        failCatalog.set(true)
        compose.onNodeWithText("Movies", substring = false).performClick()
        waitFor("Provider returned HTTP 503. Try again later.")
        failCatalog.set(false)
        compose.onNodeWithText("Try again").performClick(); waitFor("Fixture Movie")
    }
    @Test fun onDemandPlaybackPauseSeekResumeAndRetry() {
        login()
        compose.onNodeWithText("Movies", substring = false).performClick(); waitFor("Fixture Movie")
        compose.onNodeWithText("Fixture Movie").performClick(); waitFor("Fixture movie description")
        failStream.set(true)
        compose.onNodeWithText("Watch / resume").performClick()
        waitNative(15_000) { activity -> activity.window.decorView.findText("Retry playback") != null }
        failStream.set(false)
        instrumentation.runOnMainSync { resumedPlayer().window.decorView.findText("Retry playback")!!.performClick() }
        waitNative(15_000) { activity -> player(activity)?.let { it.playbackState == Player.STATE_READY && it.currentPosition > 0 } == true }
        instrumentation.runOnMainSync {
            val p = player(resumedPlayer())!!
            p.pause(); assertFalse(p.playWhenReady)
            p.seekTo(500); p.play()
        }
        waitNative(10_000) { player(it)?.currentPosition?.let { pos -> pos >= 500 } == true }
        instrumentation.runOnMainSync { resumedPlayer().finish() }
        waitFor("Watch / resume")
    }
    @Test fun liveHlsPlaybackAndBackNavigation() {
        login(); compose.onNodeWithText("Fixture News").performClick(); waitFor("News now")
        compose.onNodeWithText("Watch live").performClick()
        waitNative(20_000) { player(it)?.playbackState == Player.STATE_READY }
        instrumentation.sendKeyDownUpSync(KeyEvent.KEYCODE_MEDIA_PAUSE)
        instrumentation.sendKeyDownUpSync(KeyEvent.KEYCODE_MEDIA_PLAY)
        instrumentation.sendKeyDownUpSync(KeyEvent.KEYCODE_BACK)
        waitFor("Watch live")
    }
    private fun capture(name: String) {
        compose.waitForIdle()
        val directory = java.io.File(context.filesDir, "screenshots").apply { mkdirs() }
        java.io.File(directory, "$name.png").outputStream().use {
            instrumentation.uiAutomation.takeScreenshot().compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it)
        }
    }
    private fun resumedPlayer() = ActivityLifecycleMonitorRegistry.getInstance().getActivitiesInStage(Stage.RESUMED).filterIsInstance<PlayerActivity>().first()
    private fun player(activity: PlayerActivity): Player? = findPlayer(activity.window.decorView)?.player
    private fun findPlayer(view: android.view.View): PlayerView? {
        if (view is PlayerView) return view
        if (view is ViewGroup) for (i in 0 until view.childCount) findPlayer(view.getChildAt(i))?.let { return it }
        return null
    }
    private fun android.view.View.findText(text: String): android.widget.TextView? {
        if (this is android.widget.TextView && this.text.toString() == text && visibility == android.view.View.VISIBLE) return this
        if (this is ViewGroup) for (i in 0 until childCount) getChildAt(i).findText(text)?.let { return it }
        return null
    }
    private fun waitNative(timeout: Long, check: (PlayerActivity) -> Boolean) {
        val end = System.currentTimeMillis() + timeout
        while (System.currentTimeMillis() < end) {
            var passed = false
            instrumentation.runOnMainSync { runCatching { passed = check(resumedPlayer()) } }
            if (passed) return
            Thread.sleep(100)
        }
        fail("Native player condition did not become true within $timeout ms")
    }
}
